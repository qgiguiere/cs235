#include <iostream>
#include <istream>
#include <string>
#include <fstream>
#include <sstream>
#include "LinkedList.h"

using namespace std;

int main(int argc, char * argv[]) {
    if (argc < 3) {
        cerr << "Please provide name of input and output files";
        return 1;
    }
    cout << "Input file: " << argv[1] << endl;
    ifstream in(argv[1]);
    if (!in) {
        cerr << "Unable to open " << argv[1] << " for input";
        return 2;
    }
    cout << "Output file: " << argv[2] << endl;
    ofstream out(argv[2]);
    if (!out) {
        in.close();
        cerr << "Unable to open " << argv[2] << " for output";
        return 3;
    }

    LinkedList<int>* listInts = new LinkedList<int>();
    LinkedList<string>* listString = new LinkedList<string>();

    string line, item1;
    getline(in, line);
    istringstream line2(line);
    line2 >> item1;
    if (item1 == "INT") {
        out << "INT true" << endl;
        string length;
        while(getline(in, length)) {
            stringstream iss(length);
            string userInput;
            iss >> userInput;
            if (userInput == "insertHead") {
                int item2;
                iss >> item2;
                if(listInts->insertHead(item2) == true) {
                    out << "insertHead " << item2 << " true" << endl;
                    listInts->insertHead(item2);
                }
                else {
                    out << "insertHead " << item2 << " false" << endl;
                }
            }
            else if (userInput == "insertTail") {
                int item2;
                iss >> item2;
                if(listInts->insertTail(item2) == true){
                    out << "insertTail " << item2 << " true" << endl;
                    listInts->insertTail(item2);
                }
                else {
                    out << "insertTail " << item2 << " false" << endl;
                }
            }
            else if (userInput == "insertAfter") {
                int item2;
                int item3;
                iss >> item2;
                iss >> item3;
                if(listInts->insertAfter(item2, item3) == true) {
                    out << "insertAfter " << item2 << " " << item3 << " true" << endl;
                    listInts->insertAfter(item2, item3);
                }
                else {
                    out << "insertAfter " << item2 << " " << item3 << " false" << endl;
                }
            }
            else if (userInput == "remove") {
                int item2;
                iss >> item2;
                if(listInts->remove(item2) == true) {
                    out << "remove " << item2 << "true" << endl;
                    listInts->remove(item2);
                }
                else {
                    out << "remove " << item2 << "false" << endl;
                }
            }
            /*else if (userInput == "at") {
                int item2;
                iss >> item2;
                listInts->at(item2);
            }*/
            else if (userInput == "size") {
                out << "size ";
                out << listInts->size() << endl;
            }
            else if (userInput == "clear") {
                out << "clear true" << endl;
                listInts->clear();
            }
            else if (userInput == "printList") {
                out << "printList " << listInts->toString() << endl;
            }
            /*else if (userInput == "iterateList") {
                int item2;
                iss>>item2;
            }*/
            else if(userInput == "STRING") {
                break;
            }
            //getline(in, userInput);
            }
        }
        string length;
        out << "STRING true" << endl;
        while(getline(in, length)) {
            stringstream iss(length);
            string userInput;
            iss >> userInput;
            if (userInput == "insertHead") {
                string item2;
                iss >> item2;
                if(listString->insertHead(item2) == true) {
                    out << "insertHead " << item2 << " true" << endl;
                    listString->insertHead(item2);
                }
                else {
                    out << "insertHead " << item2 << " false" << endl;
                }
            }
            else if (userInput == "insertTail") {
                string item2;
                iss >> item2;
                if(listString->insertTail(item2) == true){
                    out << "insertTail " << item2 << " true" << endl;
                    listString->insertTail(item2);
                }
                else {
                    out << "insertTail " << item2 << " false" << endl;
                }
            }
            else if (userInput == "insertAfter") {
                string item2;
                string item3;
                iss >> item2;
                iss >> item3;
                if(listString->insertAfter(item2, item3) == true) {
                    out << "insertAfter " << item2 << " " << item3 << " true" << endl;
                    listString->insertAfter(item2, item3);
                }
                else {
                    out << "insertAfter " << item2 << " " << item3 << " false" << endl;
                }
            }
            else if (userInput == "remove") {
                string item2;
                iss >> item2;
                if(listString->remove(item2) == true) {
                    out << "remove " << item2 << "true" << endl;
                    listString->remove(item2);
                }
                else {
                    out << "remove " << item2 << "false" << endl;
                }
            }
            /*else if (userInput == "at") {
                int item2;
                iss >> item2;
                listString->at(item2);
            }*/
            else if (userInput == "size") {
                out << "size ";
                out << listString->size() << endl;
            }
            else if (userInput == "clear") {
                out << "clear true" << endl;
                listString->clear();
            }
            else if (userInput == "printList") {
                out << "printList " << listString->toString() << endl;
            }
            /*else if (userInput == "iterateList") {
                int item2;
                iss>>item2;
            }*/
        }
    
    
    

    
    
    return 0;
}