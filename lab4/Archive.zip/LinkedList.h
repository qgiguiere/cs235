#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#include "LinkedListInterface.h"
#include "Node.h"
#include <string>
#include <sstream>
#include <iostream>
#include <istream>
#include <fstream>

template <typename T>
class LinkedList : public LinkedListInterface <T> {
public:
    Node<T>* head;
    LinkedList(){head = NULL;}
		
	~LinkedList(){
		clear();
	}

    virtual bool find(T value) {
       Node<T>* search = head;
		while(search != NULL){
			if (search->data == value){
				return true;
			}
			search = search->next;
		}
		return false;
    }

    virtual bool insertHead(T value) {
        if (find(value)) {
			return false;
		}
		else if(head == NULL) {
			head = new Node<T>(value);
		}
		else {
			Node<T>* temp = new Node<T>(value);
			temp->next = head;
			head = temp;
		}
        return true;
    }

    virtual bool insertTail(T value) {
        if (find(value)) {
			return false;
		}
        else if (head == NULL){
			insertHead(value);
			return false;
		}
        Node<T>* temp = head;
		while(temp->next != NULL) {
			temp = temp->next;
		}
		if (temp->next == NULL){
			Node<T>* newNode = new Node<T>(value);
			temp->next = newNode;
			newNode->next = NULL;
        }
        return true;
	}   

    virtual bool insertAfter(T value, T insertionNode) {
        if (find(value)) {
			return false;
		}
        Node<T>* curr = head;
		while(curr != NULL){
			if (curr->data == insertionNode){
				Node<T>* newNode = new Node<T>(value);
				newNode->next = curr->next;
				curr->next = newNode;
			}
			curr = curr->next;
		}
        return true;
	}

    virtual bool remove(T value) {
		Node<T>* curr = head;
		Node<T>* deleteNode = head;
		if (head->data == value) {
			head = curr->next;
			delete curr;
			return false;
		}
		while(curr->next != NULL) {
			if (curr->next->data == value) {
				deleteNode = curr->next;
				curr->next = deleteNode->next;
				deleteNode->next = NULL;
				delete deleteNode;
				return true;
			}
		curr = curr->next;
		}
        return true;
	}

    virtual bool clear(){
		while (head != NULL){
			Node<T>* n = head->next;
			delete head;
			head = n;
		}
        return true;
	}

    /*virtual T& at(size_t index) {
		if (index >= size() || index < 0){
		    return NULL;
	    }
		else{
			Node<T>* n = head;
			int i = 0;
			while (n != NULL){
				if(i == index){
					return n->data;
				}
				i++;
				n = n->next;
			}
		}
	}*/

    virtual size_t size() const {
		Node<T>* n = head;
		int i = 0;
		while (n != NULL){
			n = n->next;
			i++;
		}
		return i;
	}

    virtual std::string toString() const {
        Node<T>* n = head;
        std::stringstream nodeList;
        while (n != NULL){
            nodeList << n->data;
            if (n->next != NULL) {
                nodeList << " ";
            }
			n = n->next;
		}
        std::string stringList = nodeList.str();
        return stringList;
    }
};
#endif