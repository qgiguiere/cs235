#ifndef MYARRAY_H
#define MYARRAY_H
#define MAX_ARRAY_SIZE	1000

template<typename T>
class MyArray {
private:
   size_t size_;
   T* array_;
public:
    MyArray(const size_t maxSize) { 
        array_ = (T*)malloc(maxSize * sizeof(T)); 
    }
    void push_back(T item) { 
        array_[size_++] = item;
        
    }
    std::string toString() const {
        stringstream out;
        out << "myArray:";
        for (size_t i = 0; i < size_; ++i) {
            out << ((i % 10) ? " " : "\n") << array_[i];
        return out.str();
        }
    }
    friend std::ostream& operator << (std::ostream& os, const MyArray<T>& myArray) {
        os << myArray.toString();
        return os;
    }
   class Iterator {
    private:
        size_t index_;
        MyArray<T>* array_ptr_;
    public:
        Iterator(MyArray<T>* array, size_t index) { 
            array_ptr_ = array;
            index_ = index;
        }
        bool operator!=(const Iterator& other) const {
            bool isPrime(int number) {
                int i;
                if (number < 2) return false;
                for (i = 2; i < numbers; ++i) {
                if (number % i == 0) return false;
                }
            return true;
            }
        }  // not-equal
        Iterator& operator++() { ... }                        // pre-increment ++
        T& operator*() const { ... }                          // dereference
        std::string toString() const {
            stringstream out;
            out << "size=" << size_ << endl;
            out << "index=" << index_ << endl;
            return out.str();
            }
    
        friend std::ostream& operator<< (std::ostream& os, const Iterator& iter) {
            os << iter.toString();
            return os;
        }
    };
    Iterator begin() { 
       return MyArray<T>::Iterator(this, 0); 
    }             // pointer to first element
    Iterator end() { 
       return MyArray<T>::Iterator(this, size_); 
    }               // pointer AFTER last element

    std::string toString() const { /*...*/ }
    friend std::ostream& operator<< (std::ostream& os, const MyArray<T>& myArray) { /*...*/ };
};
#endif // MYARRAY_H