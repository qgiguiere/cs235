#include "ExpressionManager.h"
#include <cstring>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <string>
#include <stack>
#include <sstream>
#include <stack>
#include <fstream>
#include <istream>

using namespace std;

string intToString(int in) {
	stringstream ss;
	ss << in;
	string out = ss.str();
	return out;
}
int stringToInt(string in) {
	stringstream ss;
	ss.str(in);
	int out;
	ss >> out;
	return out;
}
bool isNum(string in) {
	stringstream ss;
	ss.str(in);
	int out;
	ss >> out;
	if (ss.fail() || !ss.eof())
		return false;
	return true;
}

ExpressionManager::ExpressionManager(){}
ExpressionManager::~ExpressionManager(){}

string ExpressionManager::infix() {
    string infixExpression;
	stringstream in;
	stringstream out;
	in.str(infixExpression);
	stack<int> ops;
	string temp;
	while (!in.fail() || !in.eof()) {
		in >> temp;
		if (in.fail())
			break;
		if (isNum(temp)) {
			out << temp << ' ';
		} 
        else if (temp[0] == '(') {
			ops.push(temp[0]);
		} 
        else if (temp[0] == ')') {
			while (ops.top() != '(') {
				out << (char) ops.top() << ' ';
				ops.pop();
			}
			ops.pop();
		} 
        else if (temp[0] == '*' || temp[0] == '/' || temp[0] == '%') {
			if (ops.size() != 0) {
				while (ops.top() == '*' || ops.top() == '/' || ops.top() == '%') {
					out << (char) ops.top() << ' ';
					ops.pop();
					if (ops.size() == 0) {
						break;
                    }
				}
			}
			ops.push(temp[0]);
		} 
        else if (temp[0] == '-' || temp[0] == '+') {
			if (ops.size() != 0) {
				while (ops.top() == '*' || ops.top() == '/' || ops.top() == '%'
						|| ops.top() == '-' || ops.top() == '+') {
					out << (char) ops.top() << ' ';
					ops.pop();
					if (ops.size() == 0) {
						break;
                    }
				}
			}
			ops.push(temp[0]);
		} 
        else {
			return "invalid";
		}
	}
	while (ops.size() != 0) {
		out << (char) ops.top();
		if (ops.size() != 1) {
			out << ' ';
        }
		ops.pop();
	}
	return out.str();
}

int main (int argc, char * argv[]) {
	if (argc < 3) {
        cerr << "Please provide name of input and output files";
        return 1;
    }
    cout << "Input file: " << argv[1] << endl;
    ifstream in(argv[1]);
    if (!in) {
        cerr << "Unable to open " << argv[1] << " for input";
        return 2;
    }
    cout << "Output file: " << argv[2] << endl;
    ofstream out(argv[2]);
    if (!out) {
        in.close();
        cerr << "Unable to open " << argv[2] << " for output";
        return 3;
    }
    string line, command;
    while (getline(in, line)) {
		try {
			if (line.size() == 0) continue;
			istringstream iss(line);
			iss >> command;
			if (command == "Expression:") {
				//out << ExpressionManager::infix() << endl;
				out << "yes" << endl;
				continue;
			}
		}
		catch (std::exception& e) {
			out << e.what() << endl;
		}
    }
}